import React from 'react'
import NavbarMenu from '../NavbarMenu/NavbarMenu'
import Sidebar from '../Sidebar/Sidebar'
const Setupmailbox = () => {
  return (
    <div>
        <Sidebar/>
        <NavbarMenu/>
    </div>
  )
}

export default Setupmailbox